# SFX pack (cleaned)

141 unique sound effects, sorted into folders by use. Duplicate copies and Sound Forge `.sfk` cache files from the original pack were removed (see `duplicates_removed.csv`).

## Folders
| Folder | Use in the alphabet videos |
|---|---|
| `pop/` | letter / word / "se" reveal |
| `funny/` | fruit or animal appears (boing, squeak, slide) |
| `whoosh/` | particle burst, transitions |
| `impact/` | whack, smash, thump |
| `celebrate/` | end of the video (fanfare, xylophone finish) |
| `music/` | drums, xylophone, loops (long files, 8 s or more) |
| `animal/` `vehicle/` `voice/` `nature/` | one-off effects |

## File names
`<folder>_<description>_<seconds>s[_NN].<ext>`

* `.wav` files: the description comes from the **original file name** (BOING, WHACK3 ...).
* `.mp3` files (originally `Sound_123.mp3`): the description comes from **audio analysis** (length, pitch movement, noisiness, number of hits), not from listening. Treat `glide-up`, `glide-down`, `bell-tone`, `multi-hit`, `trill` as a best guess and rename the ones you actually use.
* All `.wav` files were converted from ADPCM to standard PCM 16-bit so they play everywhere. `.mp3` files are unchanged.

## Levels
`manifest.csv` lists peak and RMS level for every file. Many files peak at or above 0 dBFS (`clipping_risk` column), so normalise them when mixing. `hindi_videos.py` does this automatically.

## Use in `hindi_videos.py`
```json
"sfx": { "enabled": true, "dir": "sfx", "volume": 1.3,
         "events": { "clip": "funny/funny_boinger" } }
```
Events: `letter`, `se`, `word`, `clip`, `burst`, `end`. A value is a file path inside `sfx/` or just the start of a file name.

## Licence
The origin and licence of this pack are not documented. Check that you may redistribute it before making this repository public, and before monetising videos that use it.
